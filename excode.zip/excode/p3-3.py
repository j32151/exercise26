def count_vowel(s):
    vowels = 'aeiouAEIOU'
    count = 0
    for ch in s:
        if ch in vowels:
            count += 1
    return count


def is_english(s):
    for ch in s:
        if not ch.isascii():      # 영어(ASCII) 이외의 글자가 있으면
            return False
    return True


# 사용자 입력 (영어만 허용)
while True:
    text = input("문자열을 입력하세요 (영어만): ")
    if is_english(text):
        break
    print("영어만 입력해 주세요.")

print("모음의 개수:", count_vowel(text))