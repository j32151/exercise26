def calc(*args, op='+'):
    if op == '+':
        result = 0
        for n in args:
            result += n
    elif op == '*':
        result = 1
        for n in args:
            result *= n
    else:
        raise ValueError("지원하지않는연산: %s" % op)
    return result

print(calc(1, 1, 4, op='+'))
print(calc(1, 2, op='*'))
print(calc(2, 3, 4))