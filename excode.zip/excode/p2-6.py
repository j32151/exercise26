n = int(input("1에서 100 사이의 자연수를 입력하세요: "))

is_prime = True
if n < 2:
    is_prime = False
else:
    for i in range(2, n):
        if n % i == 0:
            is_prime = False
            break

if is_prime:
    print(f"{n}은 소수입니다")
else:
    print(f"{n}은 소수가 아닙니다")