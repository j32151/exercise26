a, b, c = 3, 4, 5
result = 1 / (1 + a/b + c)
print(result)

import math

a, b, c = 1, 1, -6
d = math.sqrt(b**2 - 4*a*c)
x1 = (-b + d) / (2*a)
x2 = (-b - d) / (2*a)
print(x1, x2)

r = 5
area = math.pi * r**2
print(area)

import math

beta, g = 2.0, 3.2
print(beta * math.exp(-g))

import math

x, mu, rho = 0, 1.5, 2.0
result = 1 / math.sqrt(2 * math.pi * rho) * math.exp(-(x - mu)**2 / (2 * rho**2))
print(result)