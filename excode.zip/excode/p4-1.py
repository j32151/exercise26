import os

while True:
    filename = input("읽을 파일명을 입력하세요 (종료: q): ")
    if filename == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print("파일을 찾을 수 없습니다. 다시 입력해 주세요.")
        continue

    numbered = []
    for i, line in enumerate(lines, start=1):
        numbered.append("%d %s" % (i, line.rstrip('\n')))

    for line in numbered:
        print(line)

    save_name = os.path.splitext(filename)[0] + '.sav'
    with open(save_name, 'w', encoding='utf-8') as f:
        for line in numbered:
            f.write(line + '\n')

    print("'%s' 파일로 저장했습니다." % save_name)
    break