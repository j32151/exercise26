#UDPEchoClient.py

import socket

host = '203.250.133.88'
port = 12242
BUFF_SIZE = 128

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

server_address = (host, port)

while True:
    message = input("Enter message (quit to exit) : ")
    if message == 'quit':
        break
    message = bytes(message, encoding='utf-8')

    try:
        bytes_sent = sock.sendto(message, server_address)
        data, address = sock.recvfrom(BUFF_SIZE)
        print("Received from server : %s" % data.decode())

    except Exception as e:
        print("Exception: %s" %str(e))

sock.close()