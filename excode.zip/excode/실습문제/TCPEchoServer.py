#!/usr/bin/python3

import socket

server_IP = ''
server_port = 12242
buff_size = 128
backlog = 5

conn_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
conn_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
conn_sock.bind((server_IP, server_port))
conn_sock.listen(backlog)
# print(conn_sock)

while True:
    print("waiting for requests..")
    data_sock, address = conn_sock.accept()
    # print(data_sock)
    print("echo request from {} port {}".format(address[0], address[1]))
    while True:
        message = data_sock.recv(buff_size)
        if not message:     # 클라이언트가 연결을 닫음
            break
        print("received message: {}".format(message.decode()))
        data_sock.sendall(message)
    print("client {} port {} closed".format(address[0], address[1]))
    data_sock.close()
