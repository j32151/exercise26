import socket

host = 'time-b.nist.gov'
port = 13
BUFF_SIZE = 128

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(5)

server_address = (host, port)

message = bytes("time", encoding='utf-8')

try:
    bytes_sent = sock.sendto(message, server_address)
    data, address = sock.recvfrom(BUFF_SIZE)
    print("Received from server : %s" % data.decode())

except Exception as e:
    print("Exception: %s" %str(e))

sock.close()
