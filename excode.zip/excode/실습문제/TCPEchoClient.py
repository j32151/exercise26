#!/usr/bin/python3

import socket

server_IP = '203.250.133.88'
server_port = 12242
buff_size = 128

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_addr = (server_IP, server_port)
sock.connect(server_addr)

while True:
    message = input("Enter message (quit to exit): ")
    if message == 'quit':
        break
    #message_bytes = message.encode('utf-8')

    try:
        sock.sendall(message.encode())
        data = sock.recv(buff_size)
        print("Received from server: {}".format(data.decode()))
    except Exception as e:
        print("Exception : {}".format(str(e)))
        break

sock.close()