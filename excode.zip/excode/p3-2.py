def min_max(numbers):
    min_val = numbers[0]
    max_val = numbers[0]
    for n in numbers[1:]:
        if n < min_val:
            min_val = n
        if n > max_val:
            max_val = n
    return (min_val, max_val)

data = input("정수들을 입력하세요 (공백으로 구분): ")
nums = [int(x) for x in data.split()]

result = min_max(nums)
print("min 값:", result[0])
print("max 값:", result[1])