a = int(input("첫 번째 정수: "))
b = int(input("두 번째 정수: "))

print(f"{a} + {b} = {a + b}")
print(f"{a} - {b} = {a - b}")
print(f"{a} x {b} = {a * b}")
print(f"{a} / {b} = {a / b}")

a, b = map(int, input("정수 두 개를 입력하세요: ").split())

print("{} + {} = {}".format(a, b, a + b))
print("{} - {} = {}".format(a, b, a - b))
print("{} x {} = {}".format(a, b, a * b))
print("{} / {} = {}".format(a, b, a / b))