while True:
    filename = input("읽을 파일명을 입력하세요 (종료: q): ")
    if filename == 'q':
        print("종료.")
        break

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        print("파일을 찾을 수 없습니다. 다시 입력해 주세요.")
        continue

    char_count = 0
    for ch in text:
        if not ch.isspace():
            char_count += 1

    word_count = len(text.split())

    line_count = len(text.splitlines())

    print("characters : %d" % char_count)
    print("words      : %d" % word_count)
    print("lines      : %d" % line_count)
    break