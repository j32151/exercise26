students = {}

while True:
    id = input("학번을 입력하세요 (종료: Fin!): ")
    if id == "Fin!":
        break
    name = input("이름을 입력하세요: ")
    students[id] = name

print(students)

while True:
    id = input("찾을 학번을 입력하세요 (종료: Quit!): ")
    if id == "Quit!":
        break
    if id in students:
        print(students[id])
    else:
        print("not found!")